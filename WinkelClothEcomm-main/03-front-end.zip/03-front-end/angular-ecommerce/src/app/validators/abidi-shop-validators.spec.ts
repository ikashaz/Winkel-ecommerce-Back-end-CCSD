import { AbidiShopValidators } from './abidi-shop-validators';

describe('AbidiShopValidators', () => {
  it('should create an instance', () => {
    expect(new AbidiShopValidators()).toBeTruthy();
  });
});
